#!/bin/bash
apt update && apt upgrade -y
apt install -y network-manager
apt install python3-flask -y
apt install python3-serial
apt install python3-picamera2 --no-install-recommends -y
