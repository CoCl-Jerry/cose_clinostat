import RPi.GPIO as GPIO
from utils import load_settings, save_settings

# GPIO pins for fan and IR strip
FAN_PIN = 18
IR_PIN = 17

# Setup GPIO
def setup_gpio():
    """Setup GPIO pins."""
    GPIO.setmode(GPIO.BCM)  # Use BCM GPIO numbering
    GPIO.setup(FAN_PIN, GPIO.OUT)
    GPIO.setup(IR_PIN, GPIO.OUT)

# Setup PWM for the fan
pwm = None

def setup_pwm():
    global pwm
    if pwm is not None:
        pwm.stop()  # Stop the existing PWM object
    pwm = GPIO.PWM(FAN_PIN, 25)  # Set PWM frequency to 25 Hz
    pwm.start(0)  # Start PWM with 0% duty cycle
    settings = load_settings()
    fan_speed = settings.get('fan_speed', 0)  # Default to 0 if not set
    set_fan_speed(fan_speed)  # Set the fan to the saved speed

def set_fan_speed(speed):
    """Set the fan speed."""
    if pwm is None:
        setup_pwm()
    pwm.ChangeDutyCycle(speed)
    settings = load_settings()
    settings['fan_speed'] = speed
    save_settings(settings)
    print(f"Fan set to {speed}% duty cycle")

def set_ir_strip_state(state):
    """Set the IR strip state."""
    GPIO.output(IR_PIN, GPIO.HIGH if state else GPIO.LOW)
    print(f"IR strip {'ON' if state else 'OFF'}")