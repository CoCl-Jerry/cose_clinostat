import subprocess
import os

def get_ap_credentials():
    """Retrieve the SSID and password of the Wi-Fi access point."""
    try:
        ssid_output = subprocess.check_output(
            ["nmcli", "-t", "-f", "802-11-wireless.ssid", "connection", "show", "wifi-wlan0"],
            text=True
        ).strip()
        ssid = ssid_output.split(':')[1] if ':' in ssid_output else ssid_output
        password = ssid
        return ssid, password
    except Exception as e:
        print(f"Error retrieving AP credentials: {e}")
        return "Unknown_SSID", "Unknown_Password"

def get_remaining_storage():
    """Calculate the remaining storage on the device."""
    st = os.statvfs('/')
    remaining_storage = (st.f_bavail * st.f_frsize) // (1024 * 1024)  # Storage in MB
    return remaining_storage