from flask import Flask, send_file, request, jsonify
from gpio_control import set_ir_strip_state, set_fan_speed
from camera_control import capture_image
import os
import shutil
import zipfile

app = Flask(__name__)

def read_version(file_path):
    """Read the version from the specified file."""
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            return file.read().strip()
    return None

def set_permissions_recursive(path, mode):
    """Set permissions recursively for a directory and its contents."""
    for root, dirs, files in os.walk(path):
        for dir in dirs:
            os.chmod(os.path.join(root, dir), mode)
        for file in files:
            os.chmod(os.path.join(root, file), mode)
    os.chmod(path, mode)

@app.route('/fan_speed', methods=['POST'])
def fan_speed():
    try:
        speed = int(request.form['speed'])
        set_fan_speed(speed)
        return f"FAN_SPEED_RESPONSE,Speed={speed}"
    except ValueError:
        return jsonify(error="Invalid speed value"), 400

@app.route('/ir_led', methods=['POST'])
def ir_led():
    try:
        state = int(request.form['state'])
        set_ir_strip_state(state)
        return f"IR_LED_RESPONSE,State={'ON' if state else 'OFF'}"
    except ValueError:
        return jsonify(error="Invalid state value"), 400

@app.route('/capture_image', methods=['POST'])
def capture_image_route():
    try:
        image_path = '/home/pi/captured_image.jpg'
        width = int(request.form.get('width', 1024))
        height = int(request.form.get('height', 768))
        resolution = (width, height)
        zoom_percentage = int(request.form.get('zoom_percentage', 0))
        autofocus = request.form.get('autofocus', 'true').lower() == 'true'
        lens_position = request.form.get('lens_position', None)
        if lens_position is not None:
            lens_position = float(lens_position)
        lens_position = capture_image(image_path, resolution=resolution, zoom_percentage=zoom_percentage, autofocus=autofocus, lens_position=lens_position)
        response = send_file(image_path, mimetype='image/jpeg')
        if lens_position is not None:
            response.headers['Lens-Position'] = str(lens_position)
        return response
    except Exception as e:
        return jsonify(error=str(e)), 500

@app.route('/update_code', methods=['POST'])
def update_code():
    try:
        if 'file' not in request.files:
            return jsonify(error="No file part"), 400
        file = request.files['file']
        if file.filename == '':
            return jsonify(error="No selected file"), 400
        if file and file.filename == 'core.zip':
            # Define the directory to store the code
            code_directory = '/home/pi/core'
            version_file_path = os.path.join(code_directory, 'version.txt')
            
            # Read the current version
            old_version = read_version(version_file_path)
            
            # Create a temporary directory to extract the zip file
            temp_directory = '/home/pi/temp_code'
            if os.path.exists(temp_directory):
                shutil.rmtree(temp_directory)
            os.makedirs(temp_directory)
            
            # Save the uploaded zip file to the temporary directory
            zip_path = os.path.join(temp_directory, 'core.zip')
            file.save(zip_path)
            
            # Extract the zip file
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(temp_directory)
            
            # Check if the extracted directory contains the 'core' directory
            extracted_code_directory = os.path.join(temp_directory, 'core')
            if not os.path.exists(extracted_code_directory):
                shutil.rmtree(temp_directory)
                return jsonify(error="Zip file does not contain the 'core' directory"), 400
            
            # Delete the current code directory
            if os.path.exists(code_directory):
                shutil.rmtree(code_directory)
            
            # Move the extracted code to the code directory
            shutil.move(extracted_code_directory, code_directory)
            
            # Set permissions for the new code directory and its contents
            set_permissions_recursive(code_directory, 0o777)
            
            # Clean up the temporary directory
            shutil.rmtree(temp_directory)
            
            # Read the new version
            new_version = read_version(version_file_path)
            
            # Send the response before rebooting
            response = jsonify(message="Code updated successfully. System is rebooting...", old_version=old_version, new_version=new_version)
            response.status_code = 200
            
            # Schedule a reboot after 5 seconds in a background subshell
            os.system('(sleep 2; sudo reboot) &')
            
            return response
        else:
            return jsonify(error="Invalid file type"), 400
    except Exception as e:
        return jsonify(error=str(e)), 500

@app.errorhandler(404)
def page_not_found(e):
    return jsonify(error="Page not found"), 404

@app.errorhandler(500)
def internal_server_error(e):
    return jsonify(error="Internal server error"), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)