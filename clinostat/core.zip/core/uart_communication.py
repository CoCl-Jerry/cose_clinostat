import serial
import threading
from gpio_control import set_ir_strip_state, set_fan_speed
from network_utils import get_ap_credentials, get_remaining_storage
from utils import calculate_crc16, load_settings, save_settings

# UART Setup
SERIAL_PORT = '/dev/ttyS0'  # Adjust as needed
BAUD_RATE = 9600
ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
ser.flush()
print("UART setup complete.")

def handle_handshake():
    """Handle HANDSHAKE message and respond with SSID, password, and storage."""
    set_ir_strip_state(False)  # Turn off the IR strip
    ssid, password = get_ap_credentials()
    remaining_storage = get_remaining_storage()
    response = f"HANDSHAKE_RESPONSE,SSID={ssid},PASSWORD={password},STORAGE={remaining_storage}MB"
    response_crc = calculate_crc16(response.encode('utf-8'))
    response_with_crc = f"{response},CRC={response_crc:04X}"
    print(f"Sending UART response: {response_with_crc}")
    ser.write((response_with_crc + "\n").encode('utf-8'))

def handle_fan_speed(message):
    """Handle FAN_SPEED message and update the fan speed."""
    try:
        speed_str = message.split('=')[1].split(',')[0]
        speed = int(speed_str)
        set_fan_speed(speed)
        response = f"FAN_SPEED_RESPONSE,Speed={speed}"
        response_crc = calculate_crc16(response.encode('utf-8'))
        response_with_crc = f"{response},CRC={response_crc:04X}"
        print(f"Sending UART response: {response_with_crc}")
        ser.write((response_with_crc + "\n").encode('utf-8'))
    except Exception as e:
        print(f"Error handling fan speed message: {e}")

def handle_ir_led(message):
    """Handle IR_LED message and update the IR LED state."""
    try:
        state_str = message.split('=')[1].split(',')[0]
        state = int(state_str)
        set_ir_strip_state(state)
        response = f"IR_LED_RESPONSE,State={'ON' if state else 'OFF'}"
        response_crc = calculate_crc16(response.encode('utf-8'))
        response_with_crc = f"{response},CRC={response_crc:04X}"
        print(f"Sending UART response: {response_with_crc}")
        ser.write((response_with_crc + "\n").encode('utf-8'))
    except Exception as e:
        print(f"Error handling IR LED message: {e}")

def handle_other_message(message):
    """Handle other types of messages."""
    response = f"RESPONSE,Received={message}"
    response_crc = calculate_crc16(response.encode('utf-8'))
    response_with_crc = f"{response},CRC={response_crc:04X}"
    print(f"Sending UART response: {response_with_crc}")
    ser.write((response_with_crc + "\n").encode('utf-8'))

def uart_listener():
    """Listen for UART messages and respond accordingly."""
    print("Starting UART listener...")
    while True:
        if ser.in_waiting > 0:
            message = ser.readline().decode('utf-8').strip()
            print(f"Received UART message: {message}")
            try:
                received_data, received_crc = message.rsplit(',', 1)
                received_crc = int(received_crc.split('=')[1], 16)
                calculated_crc = calculate_crc16(received_data.encode('utf-8'))
                if calculated_crc != received_crc:
                    print("CRC mismatch. Data may be corrupted.")
                    continue
                if message.startswith("HANDSHAKE"):
                    handle_handshake()
                elif message.startswith("FAN_SPEED"):
                    handle_fan_speed(message)
                elif message.startswith("IR_LED"):
                    handle_ir_led(message)
                else:
                    handle_other_message(message)
            except Exception as e:
                print(f"Error processing message: {e}")

uart_thread = threading.Thread(target=uart_listener)
uart_thread.daemon = True
uart_thread.start()