from gpio_control import setup_gpio, set_ir_strip_state, setup_pwm, pwm
from uart_communication import uart_thread, ser
import RPi.GPIO as GPIO
import time
import threading

# Setup GPIO
setup_gpio()
setup_pwm()

def run_flask():
    from app import app
    app.run(host='0.0.0.0', port=5000)

if __name__ == '__main__':
    try:
        print("Running fan and IR strip control. Press Ctrl+C to stop.")
        set_ir_strip_state(False)  # Ensure IR strip is off initially

        # Start Flask server in a separate thread
        flask_thread = threading.Thread(target=run_flask)
        flask_thread.daemon = True
        flask_thread.start()

        # Start UART listener in a separate thread if not already started
        if not uart_thread.is_alive():
            uart_thread.start()

        while True:
            time.sleep(10)  # Main loop doing nothing, just waiting

    except KeyboardInterrupt:
        print("Interrupted by user. Stopping and cleaning up...")

    finally:
        if pwm is not None:
            pwm.stop()
        set_ir_strip_state(False)  # Ensure IR strip is off before exiting
        GPIO.cleanup()  # Reset GPIO settings
        ser.close()  # Close the serial port