import json
import os

SETTINGS_FILE = 'settings.json'

def calculate_crc16(data):
    """Calculate CRC16 for the given data."""
    crc = 0xFFFF
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = (crc << 1) ^ 0x1021
            else:
                crc <<= 1
            crc &= 0xFFFF
    return crc

def load_settings():
    """Load settings from the JSON file."""
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, 'r') as file:
            return json.load(file)
    return {}

def save_settings(settings):
    """Save settings to the JSON file."""
    with open(SETTINGS_FILE, 'w') as file:
        json.dump(settings, file)