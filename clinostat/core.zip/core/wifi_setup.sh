
echo "Enabling and starting NetworkManager..."
systemctl enable NetworkManager
systemctl start NetworkManager

echo "Configuring NetworkManager to manage wlan0..."
nmcli device set wlan0 managed yes

echo "Creating a Wi-Fi Access Point..."
PREFIX="clinostat"
SERIAL=$(awk '/Serial/ {print $3}' /proc/cpuinfo)
echo "Serial Number: $SERIAL"
SERIAL_LAST4=$(echo "$SERIAL" | awk '{print substr($0, length($0)-3)}')
NEW_HOSTNAME="${PREFIX}-${SERIAL_LAST4}"
SSID="$NEW_HOSTNAME"
PASSWORD="$NEW_HOSTNAME"

echo "Removing any previous configurations for wlan0..."
EXISTING_CONNECTIONS=$(nmcli connection show | grep wlan0 | awk '{print $1}')
for CONNECTION in $EXISTING_CONNECTIONS; do
    echo "Deleting connection: $CONNECTION"
    nmcli connection delete "$CONNECTION"
done

echo "Setting hostname to: $NEW_HOSTNAME"
sudo hostnamectl set-hostname "$NEW_HOSTNAME"
sudo sed -i "s/127\.0\.1\.1.*/127.0.1.1\t$NEW_HOSTNAME/" /etc/hosts

# Create a new connection with a consistent name
nmcli connection add type wifi ifname wlan0 mode ap ssid "$SSID" connection.id "wifi-wlan0" ipv4.addresses 192.168.4.1/24 ipv4.method shared

# Set the Wi-Fi security settings
nmcli connection modify "wifi-wlan0" 802-11-wireless-security.key-mgmt wpa-psk
nmcli connection modify "wifi-wlan0" 802-11-wireless-security.psk "$PASSWORD"

# Enable autoconnect on startup
nmcli connection modify "wifi-wlan0" connection.autoconnect yes

# Bring up the Access Point
nmcli connection up "wifi-wlan0"

echo "Access Point setup complete!"
echo "SSID: $SSID"
echo "Password: $PASSWORD"
echo "Hostname set to: $NEW_HOSTNAME"
echo "This Access Point will automatically start on boot."

# Create a systemd service to automatically run main.py
cat <<EOF | sudo tee /etc/systemd/system/core.service
[Unit]
Description=Run main.py on startup
After=network.target

[Service]
ExecStart=sudo /usr/bin/python3 /home/pi/core/main.py
WorkingDirectory=/home/pi/core/
Restart=always
User=root

[Install]
WantedBy=multi-user.target
EOF

# Enable and start the service
sudo systemctl enable core.service
sudo systemctl start core.service
