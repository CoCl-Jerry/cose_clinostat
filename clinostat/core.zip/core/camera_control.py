from picamera2 import Picamera2
from libcamera import controls
import time

def capture_image(image_path, resolution=(1024, 768), zoom_percentage=0, autofocus=True, lens_position=None):
    """Capture an image with the Raspberry Pi camera without distorting the image at any zoom level."""
    with Picamera2() as picam2:
        picam2.options["quality"] = 100  # Set JPEG quality to 95
        config = picam2.create_still_configuration(main={"size": resolution})
        picam2.configure(config)
        
        # Handle focus (autofocus or manual)
        if autofocus:
            picam2.set_controls({"AfMode": controls.AfModeEnum.Auto})
            picam2.start()
            picam2.autofocus_cycle()
            time.sleep(2)  # Allow the camera to focus
            lens_position = picam2.capture_metadata().get("LensPosition")
        else:
            picam2.set_controls({"AfMode": controls.AfModeEnum.Manual})
            if lens_position is not None:
                picam2.set_controls({"LensPosition": lens_position})
            picam2.start()
        
        # Always compute a rectangle that matches 'resolution' aspect ratio
        # If zoom_percentage = 0, this simply uses the largest same-ratio region in the sensor.
        sensor_size = picam2.camera_properties['PixelArraySize']
        zoom_rect = calculate_center_zoom(sensor_size, resolution, zoom_percentage)
        picam2.set_controls({"ScalerCrop": zoom_rect})
        
        # Give the camera time to settle, then capture
        time.sleep(2)
        picam2.capture_file(image_path)
        picam2.stop()
    print(f"Image captured and saved to {image_path}")
    return lens_position


def calculate_center_zoom(sensor_size, final_res, zoom_percentage):
    """
    Return a [x, y, w, h] crop rectangle (ScalerCrop) centered within the sensor,
    preserving the aspect ratio of 'final_res' and scaled by 'zoom_percentage'.
    
    zoom_percentage = 0 => no zoom (use the largest same-aspect-ratio region).
    zoom_percentage = 50 => the largest region is halved in width/height (2× digital zoom), etc.
    """
    if not (0 <= zoom_percentage < 100):
        raise ValueError("Zoom percentage must be between 0 and 99 (100% would result in zero size).")
    
    sensor_w, sensor_h = sensor_size  # e.g. (4056, 3040)
    out_w, out_h       = final_res    # e.g. (1920, 1080)
    
    # Calculate aspect ratios
    sensor_ratio = sensor_w / sensor_h
    desired_ratio = out_w / out_h
    
    # 1) Find the largest rectangle in the sensor with the same ratio as final_res
    if sensor_ratio > desired_ratio:
        # Sensor is relatively wider, so match sensor height
        max_h = sensor_h
        max_w = int(max_h * desired_ratio)
    else:
        # Sensor is relatively taller (or same), so match sensor width
        max_w = sensor_w
        max_h = int(max_w / desired_ratio)
    
    # 2) Center that rectangle within the full sensor
    x_offset = (sensor_w - max_w) // 2
    y_offset = (sensor_h - max_h) // 2
    
    # 3) Zoom: reduce max_w/max_h by zoom_percentage
    factor = 1 - (zoom_percentage / 100.0)  # e.g. 50% => factor=0.5
    crop_w = int(max_w * factor)
    crop_h = int(max_h * factor)
    
    # Re-center the smaller rectangle
    x = x_offset + (max_w - crop_w) // 2
    y = y_offset + (max_h - crop_h) // 2
    
    return [x, y, crop_w, crop_h]


# Example usage:
# lens_position = capture_image(
#     '/home/pi/captured_image.jpg',
#     resolution=(1920, 1080),
#     zoom_percentage=50,
#     autofocus=False,
#     lens_position=1.5
# )
# print("Lens position after capture:", lens_position)
